# Archived Existing Mermaid Diagrams

Source basis: existing repo documentation as retrieved from current `README.md` and `docs/System-Design-Document.md`.

## 1. System Architecture Overview
```mermaid
flowchart TB
    subgraph Site_J64["Site J64"]
        subgraph J64M["j64manager Cluster"]
            J64M_ISTIO[Istio Control Plane]
            J64M_PROM[Prometheus Stack<br/>Central Monitoring]
            J64M_MONGO[MongoDB Operator]
            J64M_GRAFANA[Grafana Dashboard]
            J64M_ALERT[Alertmanager]
        end

        subgraph J64D["j64domain Cluster"]
            J64D_ISTIO[Istio Control Plane]
            J64D_PROM[Prometheus Agent]
            J64D_ROCKET[Rocket.Chat Pods]
            J64D_MONGO[MongoDB ReplicaSet]
        end
    end

    subgraph Site_J52["Site J52"]
        subgraph J52D["j52domain Cluster"]
            J52D_ISTIO[Istio Control Plane]
            J52D_PROM[Prometheus Agent]
            J52D_ROCKET[Rocket.Chat Pods]
            J52D_MONGO[MongoDB ReplicaSet]
        end
    end

    subgraph Site_R01["Site R01"]
        subgraph R01D["r01domain Cluster"]
            R01D_ISTIO[Istio Control Plane]
            R01D_PROM[Prometheus Agent]
            R01D_ROCKET[Rocket.Chat Pods]
            R01D_MONGO[MongoDB ReplicaSet]
        end
    end
```

## 2. Service Mesh Architecture
```mermaid
graph TB
    subgraph MeshConfig["Istio Multi-cluster Mesh"]
        subgraph Primary["Primary Cluster - j64manager"]
            P_Istiod[Istiod<br/>Control Plane]
            P_Gateway[East-West Gateway]
            P_Kiali[Kiali Server]
        end

        subgraph Remote1["Remote - j64domain"]
            R1_Istiod[Istiod<br/>Control Plane]
            R1_Gateway[East-West Gateway]
        end

        subgraph Remote2["Remote - j52domain"]
            R2_Istiod[Istiod<br/>Control Plane]
            R2_Gateway[East-West Gateway]
        end

        subgraph Remote3["Remote - r01domain"]
            R3_Istiod[Istiod<br/>Control Plane]
            R3_Gateway[East-West Gateway]
        end
    end
```

## 3. Monitoring Architecture
```mermaid
flowchart TB
    subgraph Central["Central Monitoring - j64manager"]
        Prom_Central[Prometheus<br/>Central Federation]
        Grafana[Grafana Dashboards]
        Alert[Alertmanager]
        KubeSM[kube-state-metrics]
        NodeExp[node-exporter]
    end

    subgraph Agents["Remote Clusters"]
        Prom_J64D[Prometheus<br/>j64domain]
        Prom_J52D[Prometheus<br/>j52domain]
        Prom_R01D[Prometheus<br/>r01domain]
    end
```
