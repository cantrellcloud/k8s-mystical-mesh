# K8s-Mystical-Mesh Diagram Package

This package is a documentation deliverable for the `cantrellr/k8s-mystical-mesh` repository. It was built as a **diagram package** rather than a direct repo modification, and it preserves existing Mermaid material in an archive folder.

## Included diagrams

1. Complete multi-cluster Kubernetes topology
2. Advanced networking and multi-cluster service mesh topology
3. Rocket.Chat application stack topology
4. Keycloak application stack topology
5. Monitoring and observability topology

## Deliverables per diagram

- Mermaid source in `docs/diagrams/mermaid/`
- 16:9 PNG export in `docs/diagrams/png/`


## Operating system baseline

- All Kubernetes control-plane and worker nodes are assumed to run **Ubuntu 24.04 LTS**.
- Diagram labels and planning guidance in this package should be read with Ubuntu 24.04 LTS as the node OS baseline.

## Preserved original material

- `docs/diagrams/archive/original-mermaid-archive.md`

## Design assumptions used

- 1 management cluster and 3 worker clusters
- Management cluster: `j64manager`
- Kubernetes node OS baseline: **Ubuntu 24.04 LTS**
- Worker clusters: `j64domain`, `j52domain`, `r01domain`
- In-scope platform components:
  - CoreDNS
  - cert-manager
  - MetalLB
  - Contour
  - Istio multi-cluster service mesh
  - NetApp Trident / Trident Protect
  - MongoDB operator and multi-cluster data topology
  - NATS
  - Rocket.Chat
  - Keycloak Operator with Keycloak CRs
  - Prometheus, Alertmanager, Grafana, kube-state-metrics, node-exporter
  - ELK integration
- Out of scope:
  - NSX
  - AVI / NSX Advanced Load Balancer

## Suggested repo placement

- `docs/diagrams/` for source and exports
- `docs/diagrams/archive/` for preserved older Mermaid content
- Reference selected PNGs from `README.md`
- Reference the full set from `docs/System-Design-Document.md`

## Suggested README snippet

```markdown
## Architecture Diagrams

### Multi-Cluster Overview
![Multi-Cluster Overview](docs/diagrams/png/01-multicluster-overview.png)

### Advanced Networking and Service Mesh
![Advanced Networking and Service Mesh](docs/diagrams/png/02-advanced-networking-service-mesh.png)

### Rocket.Chat Application Stack
![Rocket.Chat Application Stack](docs/diagrams/png/03-application-stack-rocketchat.png)

### Keycloak Application Stack
![Keycloak Application Stack](docs/diagrams/png/04-application-stack-keycloak.png)

### Monitoring and Observability
![Monitoring and Observability](docs/diagrams/png/05-monitoring-observability-topology.png)
```

## Notes

The Keycloak diagram intentionally shows a **HA-ready target posture** even though the current state is operator-managed Keycloak with external PostgreSQL and without active HA yet. That makes the deliverable useful for both present-state reviews and future-state planning.
