# Bare-Metal Capacity Planning Recommendations

## Purpose

This document provides **recommended physical server sizing** for the K8s-Mystical-Mesh platform assuming:

- Kubernetes node OS baseline: **Ubuntu 24.04 LTS**
- 1 management cluster and 3 worker clusters
- each worker site/cluster is expected to support **~2,000 normal users**
- each worker site/cluster must be able to absorb an **overnight surge to ~5,000 users**
- Rocket.Chat is the primary user-facing workload
- supporting platform services include Istio, Contour, MetalLB, cert-manager, NetApp Trident integration, MongoDB, NATS, Keycloak, and centralized monitoring
- persistent storage is externalized to NetApp rather than consumed from local disks as the primary persistent tier

## Executive position

The straight call: if you want a platform that can survive a jump from 2,000 to 5,000 users per site without turning into a fire drill, the worker clusters need to be sized like **real production infrastructure**, not lab hardware.

That means:

- control-plane nodes should be kept clean and overprovisioned enough to remain stable under reconciliation spikes, API churn, and service mesh overhead
- worker nodes should be sized for sustained application and sidecar load, not just nominal pod counts
- each worker site should keep **headroom for at least 30% to 40% spare capacity**
- you should plan an **N+1 worker model** at minimum, and preferably an **N+2 worker model** for the user-facing clusters

## Planning assumptions

These recommendations assume the following live on the worker clusters:

- Rocket.Chat application pods
- Rocket.Chat presence/microservice pods
- MongoDB replica member for the multi-cluster replica set
- NATS cluster participation
- Istio sidecars and east-west gateway
- Contour/Envoy ingress
- metrics exporters and node agents

These recommendations assume the management cluster carries:

- central Prometheus
- Grafana
- Alertmanager
- kube-state-metrics
- node-exporter
- Keycloak Operator
- Keycloak runtime
- MongoDB Operator
- operational tooling and automation jobs

## Recommended node counts

### Management cluster: `j64manager`

Recommended layout:

- 3 control-plane nodes
- 4 worker nodes
- 1 optional spare/expansion node

### Each worker cluster: `j64domain`, `j52domain`, `r01domain`

Recommended layout for 2,000 normal users with 5,000-user surge capacity:

- 3 control-plane nodes
- 5 worker nodes minimum
- 1 additional spare/expansion worker strongly recommended

The reason is simple: a 3-worker cluster is too skinny for this demand profile once you account for:

- maintenance windows
- node failures
- sidecar overhead from Istio
- ingress and monitoring overhead
- stateful workload contention
- rolling upgrades

## Recommended physical server specifications

## 1. Control-plane node specification

Use this for every Kubernetes control-plane node in both management and worker clusters.

| Component | Recommended Spec |
|---|---|
| CPU | **16 physical cores** minimum, modern Intel Xeon Silver/Gold or AMD EPYC |
| Memory | **128 GB RAM** |
| OS disk | 2 x 960 GB enterprise SSD in RAID 1 |
| Data / container runtime disk | 2 x 1.92 TB enterprise SSD in RAID 1 |
| Network | Dual 10 GbE minimum |
| OS | **Ubuntu 24.04 LTS** |
| Boot mode | UEFI |
| TPM | TPM 2.0 preferred |

### Why this size

For this stack, 8-core control-plane nodes are too tight once you combine:

- kube-apiserver load
- etcd overhead
- controller-manager and scheduler activity
- Istio control-plane interactions
- operator reconciliation loops
- GitOps/automation churn

Sixteen physical cores and 128 GB RAM gives the control plane room to breathe and avoids leadership-grade outages caused by “good enough” sizing.

## 2. Management cluster worker node specification

Use this for `j64manager` workers.

| Component | Recommended Spec |
|---|---|
| CPU | **24 physical cores** minimum |
| Memory | **192 GB RAM** |
| OS disk | 2 x 960 GB enterprise SSD in RAID 1 |
| Data / runtime disk | 2 x 1.92 TB enterprise SSD in RAID 1 |
| Optional local metrics scratch | 2 x 3.84 TB SSD in RAID 1 |
| Network | Dual 10 GbE minimum, **25 GbE preferred** |
| OS | **Ubuntu 24.04 LTS** |

### Why this size

The management cluster is not “small” just because it is not the user-facing tier. It runs the stuff that becomes your blast radius when things go sideways:

- Prometheus
- Alertmanager
- Grafana
- Keycloak
- MongoDB Operator
- control-plane services
- centralized automation and troubleshooting workloads

Prometheus alone can become a bully if you centralize remote write and cluster-wide scraping.

## 3. Worker cluster worker node specification

Use this for the worker nodes in `j64domain`, `j52domain`, and `r01domain`.

| Demand band | CPU | Memory | Disk | Network | OS |
|---|---:|---:|---|---|---|
| Baseline production | **32 physical cores** | **256 GB RAM** | 2 x 960 GB SSD RAID 1 OS + 2 x 1.92 TB SSD RAID 1 runtime | Dual 10 GbE minimum | Ubuntu 24.04 LTS |
| Preferred for surge-friendly posture | **40 to 48 physical cores** | **384 GB RAM** | same as above, enterprise-class SSD | **Dual 25 GbE preferred** | Ubuntu 24.04 LTS |

### Why this size

A worker node in this platform is carrying more than app containers:

- Rocket.Chat pods
- presence/microservice pods
- Envoy sidecars
- ingress overhead
- MongoDB or NATS participation
- exporters and daemonsets
- kubelet and system reserve
- maintenance and failover headroom

If you size worker nodes at 16 cores / 64 GB or 16 cores / 128 GB, you are setting yourself up for fast saturation during spikes, rebalancing, or node maintenance.

## Recommended cluster-level footprints

## Management cluster (`j64manager`)

### Recommended physical footprint

| Node Type | Count | CPU Each | RAM Each | Total CPU Cores | Total RAM |
|---|---:|---:|---:|---:|---:|
| Control-plane | 3 | 16 | 128 GB | 48 | 384 GB |
| Workers | 4 | 24 | 192 GB | 96 | 768 GB |
| Optional spare worker | 1 | 24 | 192 GB | 24 | 192 GB |

### Management cluster subtotal

- minimum deployed: **144 physical cores / 1.15 TB RAM**
- with spare: **168 physical cores / 1.34 TB RAM**

## Each worker cluster (`j64domain`, `j52domain`, `r01domain`)

### Minimum recommended footprint

| Node Type | Count | CPU Each | RAM Each | Total CPU Cores | Total RAM |
|---|---:|---:|---:|---:|---:|
| Control-plane | 3 | 16 | 128 GB | 48 | 384 GB |
| Workers | 5 | 32 | 256 GB | 160 | 1.25 TB |

### Preferred surge-ready footprint

| Node Type | Count | CPU Each | RAM Each | Total CPU Cores | Total RAM |
|---|---:|---:|---:|---:|---:|
| Control-plane | 3 | 16 | 128 GB | 48 | 384 GB |
| Workers | 6 | 40 | 384 GB | 240 | 2.25 TB |

### Worker cluster subtotal

- minimum recommended: **208 physical cores / 1.63 TB RAM**
- preferred surge-ready: **288 physical cores / 2.63 TB RAM**

## Total platform footprint

### Entire 4-cluster platform minimum

| Cluster | CPU Cores | RAM |
|---|---:|---:|
| j64manager | 144 | 1.15 TB |
| j64domain | 208 | 1.63 TB |
| j52domain | 208 | 1.63 TB |
| r01domain | 208 | 1.63 TB |

**Grand total minimum:** **768 physical cores / 6.04 TB RAM**

### Entire 4-cluster platform preferred surge-ready

| Cluster | CPU Cores | RAM |
|---|---:|---:|
| j64manager | 168 | 1.34 TB |
| j64domain | 288 | 2.63 TB |
| j52domain | 288 | 2.63 TB |
| r01domain | 288 | 2.63 TB |

**Grand total preferred:** **1,032 physical cores / 9.23 TB RAM**

## Recommended server classes

These are the kinds of boxes that fit this requirement well:

- Dell PowerEdge R760 / R7615 class
- HPE ProLiant DL380 Gen11 / DL385 Gen11 class
- Lenovo ThinkSystem SR650 V3 / SR655 V3 class

### Processor guidance

Good fit examples:

- Intel Xeon Gold class with high all-core stability and enough PCIe lanes
- AMD EPYC 9354 / 9454 / similar single-socket or dual-socket options depending BOM targets

For cost efficiency, AMD EPYC often gives you a better core-per-dollar curve for dense worker nodes.

## Practical reserve policy

Do not plan to run these clusters “hot.” Use these reserve rules:

- reserve **20% CPU** for failover and noisy-neighbor events
- reserve **20% to 25% memory** for burst absorption and JVM/Node.js variability
- keep enough worker headroom so one worker can fail without triggering widespread pod eviction pressure
- treat Prometheus growth and service mesh overhead as first-class capacity consumers

## Recommendation by risk posture

## Conservative / safer choice

For the worker clusters, buy:

- 3 control-plane nodes at **16 cores / 128 GB**
- 6 workers at **40+ cores / 384 GB**
- dual 25 GbE where budget allows

This is the right answer when uptime and surge handling matter more than shaving the BOM.

## Balanced choice

For the worker clusters, buy:

- 3 control-plane nodes at **16 cores / 128 GB**
- 5 workers at **32 cores / 256 GB**
- keep rack space and procurement path ready for a 6th worker at each site

This is the minimum I’d call professionally defensible.

## Aggressive / budget-first choice

- 3 control-plane nodes at **12 to 16 cores / 96 to 128 GB**
- 4 workers at **24 to 32 cores / 192 to 256 GB**

This will work only if the real concurrency, retention, ingress rate, Rocket.Chat usage pattern, and MongoDB profile all come in lighter than the planning target. It is not the posture I’d recommend for a serious 5,000-user surge objective.

## Final recommendation

For this architecture, the clean recommendation is:

- standardize all nodes on **Ubuntu 24.04 LTS**
- keep management control-plane nodes at **16 cores / 128 GB**
- keep management workers at **24 cores / 192 GB**
- keep worker-cluster control-plane nodes at **16 cores / 128 GB**
- keep worker-cluster workers at **32 cores / 256 GB minimum**
- use **40 to 48 cores / 384 GB** for worker nodes if you want comfortable 5,000-user surge handling per site without immediately planning another hardware refresh

That gives you a platform that is materially more likely to survive real demand, maintenance, and platform overhead without collapsing into emergency tuning.
